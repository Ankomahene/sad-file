export const defaultMarkerColor = '#2670f8';
export const zoomedInMarkerColor = '#f15e33';
