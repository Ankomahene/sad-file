import { Component } from '@angular/core';

@Component({
  selector: 'smart-mapbox',
  templateUrl: './smart-mapbox.component.html',
  styleUrls: ['./smart-mapbox.component.scss'],
})
export class SmartMapboxComponent {
  constructor() {}
}
